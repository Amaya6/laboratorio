from django.apps import AppConfig


class ResgistrolabConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'resgistrolab'
